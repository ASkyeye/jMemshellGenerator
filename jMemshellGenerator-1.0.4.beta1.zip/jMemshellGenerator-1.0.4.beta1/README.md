# jMemshellGenerator


`jMG` (Java Memshell Generator) 作为 [woodpecker](https://github.com/woodpecker-framework/woodpecker-framework-release) 的插件使用，提供常见中间件的内存马注入支持。
